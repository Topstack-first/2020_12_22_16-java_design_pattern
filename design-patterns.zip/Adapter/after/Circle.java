//
// THIS CODE SHOULD NOT BE CHANGED!!!
//
public class Circle {
	private double radius;

	public Circle(double r) {
		radius = r;
	}

	public double computeArea() {
		return 2 * Math.PI * radius * radius;
	}
}