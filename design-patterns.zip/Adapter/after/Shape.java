public interface Shape {
	public double getArea();
}
