public interface MapSite {
	public void enter(Character c);
}