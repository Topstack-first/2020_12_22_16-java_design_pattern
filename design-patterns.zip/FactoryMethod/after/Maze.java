import java.util.*;

public class Maze {
	private Vector rooms = new Vector();

	public void addRoom(Room room) {
		rooms.add(room);
	}
}