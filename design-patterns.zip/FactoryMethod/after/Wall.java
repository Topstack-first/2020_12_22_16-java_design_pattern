public class Wall implements MapSite {
	public void enter(Character c) {
		System.out.println("You hurt your nose!");
	}
}