import java.util.*;

public class Maze {
	private Vector<Room> rooms = new Vector<Room>();

	public void addRoom(Room room) {
		rooms.add(room);
	}
}