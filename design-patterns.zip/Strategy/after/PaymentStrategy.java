public interface PaymentStrategy {
	public double getPayAmount(Employee context);
}