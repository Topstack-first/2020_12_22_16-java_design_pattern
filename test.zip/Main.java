// DO NOT MODIFY THIS FILE!

class Main {
	public static void main(String[] args) {
		DocumentFactory pdfFactory = new PDFFactory();
		DocumentFactory psFactory = new PSFactory();

		Document d1 = pdfFactory.makeDocument("File1.pdf");
		Document d2 = psFactory.makeDocument("File2.ps");

		d1.print();
		d2.print();
	}
}

/**
 * When executed it outputs the following 2 lines:
 * 
 * Printing the PDF file: File1.pdf
 * Printing the PS file: File2.ps
 * 
 * 
 * IMPORTANT: The above messages should be printed by the PSDocument and PDFDocument classes.
 * 
 */