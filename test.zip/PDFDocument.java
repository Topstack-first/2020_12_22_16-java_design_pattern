// DO NOT MODIFY THIS FILE!

class PDFDocument {
	public void printPDF(String name) {
		System.out.println("Printing the PDF file: " + name);
	}
}