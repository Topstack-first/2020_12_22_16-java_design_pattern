// DO NOT MODIFY THIS FILE!

class PSDocument {
	public void printPS(String name) {
		System.out.println("Printing the PS file: " + name);
	}
}