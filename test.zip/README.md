# asdt-ftr-3

#### CITY COLLEGE , THE UNIVERSITY OF SHEFFIELD INTERNATIONAL FACULTY
ASSESSMENT HANDOUT SHEET

#### Date: Monday, 21 December 2020
#### Time: 18:10-18:50 

#### Programme of Study: MSc in Web and Mobile Development/MSc in Advanved Software Engineering

#### Unit: CCP6410 ADVANCED SOFTWARE DEVELOPMENT TECHNIQUES

#### All answers should be provided in the github classroom repository. Follow the instructions below:

## Files provided should not be modified:
* Main.java
* PDFDocument.java
* PSDocument.java

## 1. Write Java code for all interfaces/classes you find necessary so that the Main compiles and when it executes it prints the expected results. (see Main.java) 		[60%]

Your answer should be the Java files in the repo. Provide only source Java files (.java)

## 2. Which design patterns are implied in the code in Main.java?   [20%]

ANSWER: Edit this file (the README.md file) and write text here

## 3. Draw a class diagram of the solution (necessary classes/interfaces and their relationships). 	You can use any drawing tool or draw one by hand, take a photo and upload in the cloud or in the github repo.   [20%]

ANSWER: Edit this file (the README.md file) and type the URL Link to the diagram here
